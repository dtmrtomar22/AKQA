﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace MVCWebApi.Models
{
    //public class Person
    //{
    //    public int ID { get; set; }
    //    public string Name { get; set; }
    //    public string Address { get; set; }
    //    public DateTime DOB { get; set; }
    //}
    //public class PersonEntities : DbContext
    //{
    //    public DbSet<Person> Persons { get; set; }
    //}
    public class Person
    {
        [Required(ErrorMessage = "Please Enter Name e.g. John Doe")]
        [StringLength(30, MinimumLength = 3)]
        public string Name { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "Please enter valid doubleNumber")]
        public decimal Number { get; set; }
    }

}