﻿using MVCWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MVCWebApi.Controllers
{
    public class ValuesController : ApiController
    {


        //public string Get()
        //{
        //    decimal number = 234.46M;
        //    string strWord = DecimalToWordExtension.ToWords(number);
        //    return strWord;
        //}

        ///api/Values return number to word
        public string Get(string userInputNumber)
        {
            decimal number = Convert.ToDecimal(userInputNumber);
            string strWord = DecimalToWordExtension.ToWords(number);
            return strWord;
        }
    }
}